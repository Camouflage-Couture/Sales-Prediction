from __future__ import annotations

from ConfigSpace.hyperparameters.hyperparameter import IntegerHyperparameter

__all__ = ["IntegerHyperparameter"]
