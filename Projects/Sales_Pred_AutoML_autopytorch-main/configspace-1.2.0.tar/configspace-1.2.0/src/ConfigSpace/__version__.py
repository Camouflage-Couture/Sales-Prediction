"""Version information."""

# The following line *must* be the last in the module, exactly as formatted:
from __future__ import annotations

__version__ = "1.2.0"
